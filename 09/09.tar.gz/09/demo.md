## 第九节实战06





第八次课的作业，不刷新页面






				sql                          >render_tem,return字符串>
	数据库----------------Flask，web后端------------------------------------前端
						flask数据访问数据		<表单，button submit，input（name）,input(pwd)						



	异步

					sql                         
	数据库----------------Flask，web后端------------------------前端
							1.渲染页面 渲染简单的数据           1.展现
								render_template						1.bootstrap
							2.数据结构，供ajax用    			2.ajax调数据(jquery)
								json								1.list
								1.list                              2.add
								2.add                               3.del
								3.del


	引入静态文件

	jinjia2
		python渲染，生成html给浏览器
		同步，
	ajax
		js渲染
		异步加载，局部刷新
		web2.0

	首屏加载jinjia2，异步数据ajax

	
	


