#!/usr/bin/env python
# coding=utf-8
from flask import Flask,request,render_template
import MySQLdb as mysql

db=mysql.connect(user='reboot',passwd='reboot123',db='liuziping',charset='utf8')
db.autocommit(True)
cur = db.cursor()

logs = open("www_access_20140823.log")
data_dict = {}
while True:
    log = logs.readline()
    if log:
        log_list = log.split()
        ip = log_list[0]
        url = log_list[6]
        http_status= log_list[8]
        if http_status in data_dict:
            if url in data_dict[http_status]:
                data_dict[http_status][url][ip] =data_dict[http_status][url].get(ip,0) + 1
            else:
                data_dict[http_status][url] = {ip:1}
        else:
            data_dict[http_status] = {url:{ip:1}}
    else:
        break
for d in sorted([(status,url,(ip,num)) for status,url_ip \
	 in data_dict.items()\
	 for url,ip_num in url_ip.items()\
	 for ip,num in ip_num.items() ],key=lambda a:a[2][1])[:-10:-1]:
        print d
	sql = "insert into logs values ('%s','%s','%s','%d')" % d
	print sql
	cur.execute(sql)
