from flask import Flask,request,render_template
import MySQLdb as mysql

app = Flask(__name__)
db=mysql.connect(user='reboot',passwd='reboot123',db='test',charset='utf8')
db.autocommit(True)
cur = db.cursor()

@app.route('/addForm')
def addForm():
	return render_template('add.html')

@app.route('/test_data',methods=['GET'])
def test_data():
	return  "this is test"
@app.route('/test',methods=['GET'])
def test():
	return render_template('demo.html',)


@app.route('/add',methods=['GET'])
def add():
	name = request.args.get('user')
	age = request.args.get('age')
	if not name:
		return 'need a name'
	if not age:
		return 'need age'
        sql="insert into admin  values ('%s','%s')"%(name,age)
	cur.execute(sql)
	return "success"
@app.route('/',methods=['GET'])
def index():
	cur.execute('select * from admin')
	str = []
	for result in cur.fetchall():
		str.append(result)
		#str+="name is %s,age is %s <br>" % (result[0],result[1]) 
	return str
	#return render_template('index.html',result=str)
@app.route('/get_log')
def log():
	cur.execute('select * from logs')
	str = ""
	for c in cur.fetchall():
		str+="%s,%s,%s,%s <br>"% c
	return str
if __name__=='__main__':
	app.run(host='0.0.0.0',port=9199,debug=True)
