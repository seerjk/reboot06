from flask import Flask,request,render_template
import MySQLdb as mysql
import json

app = Flask(__name__)
db=mysql.connect(user='reboot',passwd='reboot123',db='liuziping',charset='utf8')
db.autocommit(True)
cur = db.cursor()


@app.route('/',methods=['GET'])
def index():
	return render_template('demo.html',)


@app.route('/add',methods=['GET'])
def add():
	name = request.args.get('name')
	ip = request.args.get('ip')
	return_dict = {'error':1,'msg':''}
	if not name:
		return_dict['msg'] = 'need a name'
		return json.dumps(return_dict)
	if not ip:
		return_dict['msg'] = 'need a ip'
		return json.dumps(return_dict)
        sql="insert into cmdb_test (name,ip) values ('%s','%s')"%(name,ip)
	cur.execute(sql)
	return_dict['error'] = 0
	return json.dumps(return_dict)
@app.route('/select',methods=['GET'])
def select():
	cur.execute('select * from cmdb_test')
	str = ""
	for c in cur.fetchall():
		s = '<tr><td>%s</td> \
			<td>%s</td> \
			<td>%s</td> \
			<td><button  class="btn btn-primary" data-id="%s">update</button> \
			<button  class="btn btn-danger" data-id="%s">delete</button>  \
			</td></tr>' % (c[0],c[1],c[2],c[0],c[0])
		str = str+s
		#str+="name is %s,ip is %s <br>" % (result[1],result[2]) 
#	return json.dumps(str)
	return str
#select from id
@app.route('/getbyid',methods=['GET'])
def getbyid():
	id = request.args.get('id')
        if not id:
		return "need an id"
	
	sql = "select * from cmdb_test where id=%s" % (id)
	cur.execute(sql)
	return json.dumps(cur.fetchone())
@app.route('/delete',methods=['GET'])
def delete():
	id = request.args.get('id')
	if not id:
		return "need an id"
	sql = "delete from cmdb_test where id=%s" % (id)
	cur.execute(sql)
	return 'ok'
if __name__=='__main__':
	app.run(host='0.0.0.0',port=9199,debug=True)
