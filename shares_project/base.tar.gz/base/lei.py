#!/usr/bin/env python

class unit:
	def __init__(self,name):
		self.name = name
		self.blood = 100
		print self.name+"create"
class machinegun(unit):      #jicheng
	def attack(self,u):  
		u.blood -=30
		print u.name + " was accacked blood "+str(u.blood)
j1=machinegun('j1')
j2=machinegun('j2')
j1.attack(j2)
