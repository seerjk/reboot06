#!/usr/bin/env python
class A:
	def __init__(self,name):
		print name
		self.name = name
class B(A):
	def __init__(self,name,age):
		A.__init__(self,name)
		self.age = age
		print self.age
b=B('cjk',30)
